ignore "Use camelCase"
ignore "Eta reduce"
