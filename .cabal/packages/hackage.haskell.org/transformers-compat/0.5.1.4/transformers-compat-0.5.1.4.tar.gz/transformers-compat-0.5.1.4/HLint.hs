ignore "Warning: Avoid lambda"
