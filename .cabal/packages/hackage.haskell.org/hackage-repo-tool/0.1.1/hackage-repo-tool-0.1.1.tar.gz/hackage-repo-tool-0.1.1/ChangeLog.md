0.1.1
-----
* Update for hackage-security-0.5

0.1.0.1
-------
* Add missing module to other-modules (#100)
* Allow for hackage-security-0.3
* Include ChangeLog.md in sdist (#98)

0.1.0.0
-------
* Initial (beta) release
