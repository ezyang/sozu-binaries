{-# LANGUAGE CPP, NoImplicitPrelude #-}
module Data.Functor.Const.Compat (Const(..)) where

import Control.Applicative (Const(..))
