{-# OPTIONS_HADDOCK hide #-}
module System.Console.ANSI.Windows (
#include "Exports-Include.hs"
    ) where

import System.Console.ANSI.Common
import System.Console.ANSI.Windows.Emulator
