1.0.1
-----

- Add support for `integer-simple`
