### 0.1.3 [2017-01-30]
* The MinTTY-detection portion of this library has been split off into `mintty`, on which `echo` now depends.

### 0.1.2 [2017-01-09]
* Use more efficient implementation for `bracketInputEcho`.

### 0.1.1 [2017-01-07]
* Use `System.Win32.MinTTY` from `Win32-2.5` or later if possible.

## 0.1 [2016-12-22]
* First version.
