module Lib where

dummy :: IO ()
dummy = return ()

