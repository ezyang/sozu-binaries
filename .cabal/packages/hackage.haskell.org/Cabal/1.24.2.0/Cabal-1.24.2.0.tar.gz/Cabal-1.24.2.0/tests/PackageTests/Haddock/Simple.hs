module Simple where

-- | For hiding needles.
data Haystack = Haystack
