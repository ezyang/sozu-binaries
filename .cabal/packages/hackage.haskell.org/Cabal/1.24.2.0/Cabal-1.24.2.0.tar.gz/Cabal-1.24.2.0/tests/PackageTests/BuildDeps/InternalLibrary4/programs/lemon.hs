import Text.PrettyPrint
import MyLibrary

main = do
    putStrLn (render (text "foo"))
    myLibFunc
