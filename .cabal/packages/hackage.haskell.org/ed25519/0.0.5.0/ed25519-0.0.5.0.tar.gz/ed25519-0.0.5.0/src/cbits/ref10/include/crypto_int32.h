#ifndef crypto_int32_h
#define crypto_int32_h

#include <stdint.h>
typedef int32_t crypto_int32;

#endif
