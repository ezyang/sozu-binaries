#ifndef _ED25519_RANDOMBYTES_H_
#define _ED25519_RANDOMBYTES_H_

static inline void ed25519_randombytes(unsigned char *, unsigned long long);

#endif /* _ED25519_RANDOMBYTES_H_ */
