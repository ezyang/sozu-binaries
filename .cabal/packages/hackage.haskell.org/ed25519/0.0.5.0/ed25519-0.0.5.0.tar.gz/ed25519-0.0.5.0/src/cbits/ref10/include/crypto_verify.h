#ifndef crypto_verify_16_H
#define crypto_verify_16_H

static inline int crypto_verify_16(const unsigned char *,const unsigned char *);
static inline int crypto_verify_32(const unsigned char *,const unsigned char *);

#endif
