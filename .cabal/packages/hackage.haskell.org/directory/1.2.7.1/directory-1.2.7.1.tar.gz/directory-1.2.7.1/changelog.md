Changelog for the [`directory`][1] package
==========================================

## 1.2.7.1 (November 2016)

  * Don't abort `removePathForcibly` if files or directories go missing.
    In addition, keep going even if an exception occurs.
    ([#60](https://github.com/haskell/directory/issues/60))

## 1.2.7.0 (August 2016)

  * Remove deprecated C bits.  This means `HsDirectory.h` and its functions
    are no longer available.
    ([#50](https://github.com/haskell/directory/issues/50))

  * Add `doesPathExist` and `getFileSize`
    ([#57](https://github.com/haskell/directory/issues/57))

  * Add `renamePath`
    ([#58](https://github.com/haskell/directory/issues/58))

  * Add `removePathForcibly`
    ([#59](https://github.com/haskell/directory/issues/59))

## 1.2.6.3 (May 2016)

  * Add missing import of `(<*>)` on Windows for `base` earlier than 4.8.0.0
    ([#53](https://github.com/haskell/directory/issues/53))

## 1.2.6.2 (April 2016)

  * Bundled with GHC 8.0.1

  * Fix typo in file time functions when `utimensat` is not available and
    version of `unix` package is lower than 2.7.0.0

## 1.2.6.1 (April 2016)

  * Fix mistake in file time functions when `utimensat` is not available
    ([#47](https://github.com/haskell/directory/pull/47))

## 1.2.6.0 (April 2016)

  * Make `findExecutable`, `findExecutables`, `findExecutablesInDirectories`,
    `findFile`, and `findFilesWith` lazier
    ([#43](https://github.com/haskell/directory/issues/43))

  * Add `findFileWith`

  * Add `copyFileWithMetadata`, which copies additional metadata
    ([#40](https://github.com/haskell/directory/issues/40))

  * Improve error message of `removeDirectoryRecursive` when used on a
    directory symbolic link on Windows.

  * Add `isSymbolicLink`

  * Drop support for Hugs.

## 1.2.5.1 (February 2016)

  * Improve error message of `getCurrentDirectory` when the current working
    directory no longer exists
    ([#39](https://github.com/haskell/directory/issues/39))

  * Fix the behavior of trailing path separators in `canonicalizePath` as well
    as `makeAbsolute` when applied to the current directory; they should now
    match the behavior of `canonicalizePath` prior to 1.2.3.0 (when the bug
    was introduced)
    ([#42](https://github.com/haskell/directory/issues/42))

  * Set the location in IO errors from `makeAbsolute`.

## 1.2.5.0 (December 2015)

  * Add `listDirectory`, which is similar to `getDirectoryContents`
    but omits `.` and `..`
    ([#36](https://github.com/haskell/directory/pull/36))

  * Remove support for `--with-cc=` in `configure`; use the `CC=` flag instead
    ([ghc:D1608](https://phabricator.haskell.org/D1608))

## 1.2.4.0 (September 2015)

  * Work around lack of `#const_str` when cross-compiling
    ([haskell-cafe](F7D))

  * Add `findExecutablesInDirectories`
    ([#33](https://github.com/haskell/directory/pull/33))

  * Add `exeExtension`

[F7D]: https://mail.haskell.org/pipermail/haskell-cafe/2015-August/120892.html

## 1.2.3.1 (August 2015)

  * Restore support for Safe Haskell with base < 4.8
    ([#30](https://github.com/haskell/directory/issues/30))

## 1.2.3.0 (July 2015)

  * Add support for XDG Base Directory Specification
    ([#6](https://github.com/haskell/directory/issues/6))

  * Implement `setModificationTime` counterpart to `getModificationTime`
    ([#13](https://github.com/haskell/directory/issues/13))

  * Implement `getAccessTime` and `setAccessTime`

  * Set the filename in IO errors from the file time functions

  * Fix `canonicalizePath` so that it always returns a reasonable result even
    if the path is inaccessible and will not throw exceptions unless the
    current directory cannot be obtained
    ([#23](https://github.com/haskell/directory/issues/23))

  * Corrected the trailing slash behavior of `makeAbsolute`
    so that `makeAbsolute "" == makeAbsolute "."`

  * Deprecate use of `HsDirectory.h` and `HsDirectoryConfig.h`

  * Implement `withCurrentDirectory`

## 1.2.2.1 (Apr 2015)

  * Fix dependency problem on NixOS when building with tests
    ([#24](https://github.com/haskell/directory/issues/24))

## 1.2.2.0 (Mar 2015)

  * Bundled with GHC 7.10.1

  * Make `getModificationTime` support sub-second resolution on Windows

  * Fix silent failure in `createDirectoryIfMissing`

  * Replace `throw` by better defined `throwIO`s

  * Avoid stack overflow in `getDirectoryContents`
    ([#17](https://github.com/haskell/directory/pull/17))

  * Expose `findExecutables`
    ([#14](https://github.com/haskell/directory/issues/14))

  * `removeDirectoryRecursive` no longer follows symlinks under any
    circumstances
    ([#15](https://github.com/haskell/directory/issues/15))

  * Allow trailing path separators in `getPermissions` on Windows
    ([#9](https://github.com/haskell/directory/issues/9))

  * `renameFile` now always throws the correct error type
    (`InappropriateType`) when the destination is a directory, as long as the
    filesystem is not being modified concurrently
    ([#8](https://github.com/haskell/directory/pull/8))

  * Add `makeAbsolute`, which should be preferred over `canonicalizePath`
    unless one requires symbolic links to be resolved

## 1.2.1.0 (Mar 2014)

  * Bundled with GHC 7.8.1

  * Add support for sub-second precision in `getModificationTime` when
    linked against `unix>=2.6.0.0`

  * Fix `createDirectoryIfMissing _ "."` in `C:\` on Windows

  * Remove support for NHC98 compiler

  * Update package to `cabal-version >= 1.10` format

  * Enhance Haddock documentation for `doesDirectoryExist` and
    `canonicalizePath`

  * Fix `findExecutable` to check that file permissions indicate executable

  * New convenience functions `findFiles` and `findFilesWith`

[1]: https://hackage.haskell.org/package/directory
