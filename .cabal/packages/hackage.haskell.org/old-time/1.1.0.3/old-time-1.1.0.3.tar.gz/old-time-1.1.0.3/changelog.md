# Changelog for [`old-time` package](http://hackage.haskell.org/package/old-time)

## 1.1.0.3  *Nov 2014*

  * Decoupled from GHC distribution

## 1.1.0.2  *Mar 2014*

  * Bundled with GHC 7.8.1

  * Supports `base-4.7.0.0`

  * Remove NHC98-specific code

  * Update to Cabal 1.10 format

## 1.1.0.1  *Sep 2012*

  * Bundled with GHC 7.6.1

  * Don't include deprecated `<sys/timeb.h>` on FreeBSD

  * Fix `gettimeofday(2)` call on Win64
